<template>
  <headerMenu />
  <h1>hello</h1>
  <div class="about">
    <h1>This is an about page</h1>
  </div>
</template>

<script>
import headerMenu from "@/components/headerMenu.vue";
export default {
  components: {
    headerMenu,
  }
}
</script>