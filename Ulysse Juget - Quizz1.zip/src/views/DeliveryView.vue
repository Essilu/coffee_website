<template>
  <headerMenu />
</template>

<script>
import headerMenu from "@/components/headerMenu.vue";
export default {
  components: {
    headerMenu,
  }
}
</script>

<style>

</style>